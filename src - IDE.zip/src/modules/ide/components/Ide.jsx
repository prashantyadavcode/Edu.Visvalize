import React, { useRef } from 'react'
import Editor from '@monaco-editor/react';
import Button from '@mui/material/Button';

const Ide = () => {
    const editorRef = useRef(null);
    const mount = (editor) =>{
        editorRef.current = editor;
    }
    const getCode = () =>{
        const code = editorRef.current.getValue();
        console.log('Code is ', code);
    }
    const skeletonCode = `class Solution {
        public:
            int timeRequiredToBuy(vector<int>& tickets, int k) {
                
            }
        };
    }`;
  return (
    <>
    <Editor
        onMount = {mount}
        height="80vh"
        defaultLanguage="java"
        defaultValue={skeletonCode}
      />
      <Button onClick={getCode} variant="contained" href="#contained-buttons">
        Submit Code
      </Button>
    </>
  )
}

export default Ide
