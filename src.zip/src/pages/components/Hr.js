import React from "react";

function Hr() {
	return (
		<hr
			style={{
				display: "block",
				height: "1px",
				border: "0",
				borderTop: "1px solid #ccc",
				margin: " .5em 0",
				padding: "0",
			}}
		/>
	);
}

export default Hr;
