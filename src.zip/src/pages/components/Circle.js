import React from "react";
import "./../../css/Circle.css";

export default function Circle({ element, length }) {
	return <div className="Circle">{element}</div>;
}
